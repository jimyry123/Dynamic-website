from my_app import app

"""
How to run a Flask application:
---------------------------

1) Make sure the server is not already running:
    Go to http://127.0.0.1:5000
        It should give you a message "Unable to Connect"

2) Run this file by either clicking F5 or the green triangle icon on top

3) Go again to http://127.0.0.1:5000

"""

app.secret_key="super duper secret key"
"""
DON'T TELL THE SUPER SECRET KEY TO ANYONE. REMOVING THE KEY BREAKS THE PROGRAM.
"""
app.run()

