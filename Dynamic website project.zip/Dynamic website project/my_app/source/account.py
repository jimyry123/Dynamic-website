from flask import render_template, request, redirect, url_for, flash
from my_app.source.models import AccountForm
#from my_app.source.models import cursor, conn

def login():
#    notes: logical steps to take
#    state credientials username=admin, password=password
#    if incorrect account info give warning message:
#    else go to the account page, session=true
#    from the login page create a logout button
#    button sets session from true to false.
    
    
    
    form =AccountForm(request.form)
    
    if request.method == 'POST' and form.validate():
        username = form.username.data
        password = form.password.data
        if username !='admin' or password!='password':
            flash ('incorrect account information')
        else:
#            session=True
            return redirect(url_for('admin.html'))

    return render_template('login.html')


#def logout():
#    session['login']=False
#    return redirect(url_for(home.html))