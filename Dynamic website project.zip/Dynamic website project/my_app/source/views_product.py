from flask import render_template, request, redirect, url_for, flash
from my_app.source.models import ProductForm
from my_app.source.models import cursor, conn


#-------------------- Product Handler --------------------
#all products page
#select and populate page joining car_table and car_sub_table 
#data passed with my_list
def products(): 
    
    command = """SELECT {a}.Product_id, {a}.Name, {a}.Price,{a}.Units_in_stock,{a}.Product_color,{a}.Condition,{b}.Car_type
                     FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
        """.format(a="car_table", b='car_sub_table')
    cursor.execute(command)
    car_data = cursor.fetchall()  
    
    return render_template('products.html', my_list=car_data)
#same as products just used table
def products1():

    command = """SELECT {a}.Product_id, {a}.Name, {a}.Price,{a}.Units_in_stock,{a}.Product_color,{a}.Condition,{b}.Car_type
                     FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
                     Where {a}.Condition Like "%Used%"
        """.format(a="car_table", b='car_sub_table')
    cursor.execute(command)
    car_data = cursor.fetchall()  
    
    return render_template('products.html', my_list=car_data)
#same as products just preowned 
def products2():

    command = """SELECT {a}.Product_id, {a}.Name, {a}.Price,{a}.Units_in_stock,{a}.Product_color,{a}.Condition,{b}.Car_type
                     FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
                     Where {a}.Condition Like "%Certified pre-owned%"
        """.format(a="car_table", b='car_sub_table')
    cursor.execute(command)
    car_data = cursor.fetchall()  
    
    return render_template('products.html', my_list=car_data)
    
#-------------------- Product Key Handler --------------------
#product key handler selects type_id as the primary key
#command joins table together using common variable type_id
#data stored as item
#Parameters: Key, integer

def product(key):    
    
    command = """SELECT {a}.Product_id, {a}.Name, {a}.Price,{a}.Units_in_stock,{a}.Product_color,{a}.Condition,{b}.Car_type,{a}.URL
                      FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
                      WHERE {a}.rowid = {p1}
        """.format(a="car_table", b='car_sub_table', p1=key)
    cursor.execute(command)
    car_data = cursor.fetchall()  
      
    if len(car_data) == 0:
        return "The key "+ key + " was not found"    
    item = car_data[0]
    
    return render_template('product.html', single_product=item)

# Product Create -----------------
#cursor creates connection to db table car_table
# next_id iterates through the column type_id
#form accesses models page, request for the input variables. 
#command insert input variables to corresponding columns
#conn.commit finalizes and saves changes to the database. Without commit all changes are lost.
def product_create():
    command = """ SELECT MAX(Product_id)
                    FROM car_table
            """
    cursor.execute(command)
    next_id = cursor.fetchone()   
    product_id = next_id[0]+1
        
    form = ProductForm(request.form, csrf_enabled=False)

    command = """ SELECT car_sub_table.Type_id, Car_sub_table.Car_type
                    FROM car_sub_table
            """
    cursor.execute(command)
    Car_type = cursor.fetchall() #categories is arbitrary variable can use sub table

    form.Type_id.choices = Car_type
    
    if request.method == 'POST' and form.validate():
        Name = form.Name.data
        Price = form.Price.data
        Units_in_stock = form.Units_in_stock.data
        Product_color = form.Product_color.data
        Condition = form.Condition.data
        Type_id = form.Type_id.data
        Url = form.Url.data
        
        command = """
        Insert INTO car_table
            (Product_id,Name,Price,Units_in_stock,Product_color,Condition,Type_id,Url) VALUES 
            ('{i}','{n}',{p},{u},'{c}','{s}',{v},'{z}')
            """.format(i=product_id,n=Name, p=Price, u=Units_in_stock, c=Product_color, s=Condition, v=Type_id, z=Url )
        
        cursor.execute(command)
        conn.commit()
        
        flash('success')
        return redirect(url_for('my_view.product', key=product_id))

    if form.errors:
        flash(form.errors, 'danger')

    return render_template('product-create.html', form=form, product_id=product_id)

# 2) Product Edit -----------------
#select only the column type_id in car_table
#single category fetches all column
#form inputs categroy changes
#command updates the car_sub_table varibles
#conn saves changes to the database
def product_edit(key):
    command = """ SELECT *
                    FROM car_table
                    WHERE Product_id = {p1}
            """.format(p1=key)    
    cursor.execute(command)
    single_product = cursor.fetchall()[0]
    
    form = ProductForm(request.form, csrf_enabled=False, Name=single_product[1], Price = single_product[2], 
                       Units_in_stock = single_product[3],Product_color = single_product[4],Condition=single_product[5],
                       car_sub_table=single_product[6],Url=single_product[7])

    command = """ SELECT car_sub_table.Type_id, Car_sub_table.Car_type
                    FROM car_sub_table
            """
    cursor.execute(command)
    Car_type = cursor.fetchall()

    form.Type_id.choices = Car_type

    if request.method == 'POST' and form.validate():
        Name = form.Name.data
        Price = form.Price.data
        Units_in_stock = form.Units_in_stock.data
        Product_color = form.Product_color.data
        Condition = form.Condition.data
        Type_id = form.Type_id.data
        Url = form.Url.data
        
        command = """
            UPDATE car_table SET Name = '{n}', Price = '{p}', Units_in_stock = '{u}',
            Product_color='{c}', Condition='{s}',Type_id='{v}', Url='{z}'
            WHERE  Product_id = {i}
            """.format(i=key, n=Name, p=Price, u=Units_in_stock, c=Product_color, s=Condition, v=Type_id, z=Url )
        cursor.execute(command)
        conn.commit()
        
        flash('success')
        return redirect(url_for('my_view.product', key=key))

    if form.errors:
        flash(form.errors, 'danger')

    return render_template('product-edit.html', form=form, product_id = key)

# 3) Product Delete -----------------
#select from car_sub_table type_id 
#delete row associated with type_id 
def product_delete(key):
    command = """ SELECT *
                    FROM car_table
                    WHERE car_table.Product_id = {p1}
            """.format(p1=key)
    cursor.execute(command)
    single_category = cursor.fetchall()  
    name = single_category[0][1]
    command = """ DELETE FROM car_table
                    WHERE car_table.Product_id = {p1}
            """.format(p1=key)
    cursor.execute(command) 
    conn.commit()   
    
    flash('The product %s has been deleted' % (name), 'success')
    return redirect(url_for('my_view.home'))

# ----------------- Search -----------------
#search parameters
def product_search():  
    name = request.args.get('name')
    price = request.args.get('price')
    category = request.args.get('category')
    price_greater_equal = request.args.get('price_ge')
    price_smaller_equal = request.args.get('price_se')
#------------------------------------------------------------
#aside from name, all search function has to be enclosed in "quotations"
# if string input then a coindition is met and goes to the corresponding search parameter
# if no input then condition goes to condition 
    condition = ""
    if name != None:
        condition += "car_table.Name LIKE '%"+name+"%'"
    if price != None:
        if condition !="":
            condition += " AND "
        condition += "car_table.price = "+str(price)
    if category != None:
        if condition != "":
            condition += " AND "
        condition  += "car_table.Type_id= "+str(category)
    if price_greater_equal != None:
        if condition != "":
            condition += " AND "
        condition  += "car_table.price >= " + str(price_greater_equal)
    if price_smaller_equal != None:
        if condition != "":
            condition += " AND "
        condition  += "car_table.price <= " + str(price_smaller_equal)            
           
    if condition == "":
        command = """SELECT {a}.Product_id, {a}.Name, {a}.Price,{a}.Units_in_stock,{a}.Product_color,{a}.Condition,{b}.Car_type
                      FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
            """.format(a="car_table", b='car_sub_table')        
    else:
        command = """SELECT {a}.Product_id, {a}.Name, {a}.Price,{a}.Units_in_stock,{a}.Product_color,{a}.Condition,{b}.Car_type
                      FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
                          WHERE {cond}
            """.format(a="car_table", b='car_sub_table', cond = condition)
       
    cursor.execute(command)
    car_data = cursor.fetchall()      
    return render_template('products.html', my_list=car_data)