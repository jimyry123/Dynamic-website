from flask import render_template, request, redirect, url_for, flash
from my_app.source.models import CategoryForm
from my_app.source.models import cursor, conn



#-------------------- Category Handler --------------------
#category handler retries all car_sub_table variables
#variables stored in subtable_data
#data passed along as my_list to categories.html
def categories():   
    command = """SELECT {a}.Type_id, {a}.Car_type, {a}.Car_description, {a}.Types_in_stock,{a}.Make_up_percentage
                      FROM {a} 
              """.format(a='car_sub_table')
    cursor.execute(command)
    subtable_data = cursor.fetchall()  

    return render_template('categories.html', my_list=subtable_data)

#-------------------- Category Key Handler --------------------
#category key handler selects type_id as the primary key
#command joins table together using common variable type_id
#data stored as car_type, my_list, and type_id as the key
#Parameters: Key, integer
def category(key):
    command = """SELECT *
                   FROM car_sub_table 
                   WHERE car_sub_table.Type_id = {p1}
        """.format(p1=key)
    cursor.execute(command)
    Car_type = cursor.fetchall()[0][1]
    
    command = """SELECT {a}.rowid, {a}.Product_id, {a}.Name, {a}.Price, {a}.Units_in_stock, {a}.Product_color,{b}.Car_type,{a}.URL
              	   FROM {a} join {b} ON {a}.Type_id = {b}.Type_id
              	   WHERE {a}.Type_id = {p1}
        """.format(a='car_table', b='car_sub_table', p1=key)
        
    cursor.execute(command)
    car_data = cursor.fetchall()  
   
    return render_template('category.html', Type_id = key, 
                           Car_type=Car_type, my_list=car_data)
        

# ----------------- Category create -----------------
#cursor creates connection to db table car_sub_table
# next_id iterates through the column type_id
#form accesses models page, request for the input variables. 
#command insert input variables to corresponding columns
#conn.commit finalizes and saves changes to the database. Without commit all changes are lost.
def category_create():
    command = """ SELECT Max(Type_id)
                    FROM car_sub_table
            """
    cursor.execute(command)
    next_id = cursor.fetchone() 
    Type_id = next_id[0]+1
    
    form = CategoryForm(request.form)
       
    result = None
    if request.method == 'POST' and form.validate():
        Car_type = form.Car_type.data
        Car_description = form.Car_description.data
        Types_in_stock= form.Types_in_stock.data
        Make_up_percentage= form.Make_up_percentage.data
        
        command = """
            INSERT INTO car_sub_table 
            (Type_id,Car_type,Car_description,Types_in_stock,Make_up_percentage) VALUES 
            ({i},'{c}','{d}',{t},{m})
            """.format(i=Type_id,c=Car_type,d=Car_description,t=Types_in_stock,m=Make_up_percentage)
        
        cursor.execute(command)
        conn.commit()
        
        flash('The category %s, ID: %d has been created' % (Car_type,Type_id), 'success')
        return redirect(url_for('my_view.categories'))
    
    return render_template('category-create.html', form=form, result=result)


# ----------------- Category Edit -----------------
#select only the column type_id in car_sub_table
#single category fetches all column
#form inputs categroy changes
#command updates the car_sub_table varibles
#conn saves changes to the database
#
def category_edit(key):
    command = """ SELECT *
                    FROM car_sub_table
                    WHERE Type_id = {p1}
            """.format(p1=key)    
    cursor.execute(command)
    single_category = cursor.fetchall()[0]     
    
    form = CategoryForm(request.form, csrf_enabled=False, Car_type=single_category[1])
       
    if request.method == 'POST' and form.validate():
        Car_type = form.Car_type.data
        Car_description = form.Car_description.data
        Types_in_stock = form.Types_in_stock.data
        Make_up_percentage = form.Make_up_percentage.data
        
        
        command = """
            UPDATE car_sub_table SET Car_type = '{c}', Car_description = '{d}', Types_in_stock = '{t}', Make_up_percentage = '{m}'
            WHERE  Type_id = {i}
            """.format(c=Car_type, d=Car_description, t=Types_in_stock, m=Make_up_percentage, i=key)
        cursor.execute(command)
        conn.commit()
        
        flash('The category has been edited to %s' % (Car_type), 'success')
        return redirect(url_for('my_view.category', key=key))
    
    return render_template('category-edit.html', form=form, Type_id = key)

# ----------------- Category delete -----------------
#select from car_sub_table type_id 
#delete row associated with type_id 
def category_delete(key):
    command = """ SELECT *
                    FROM car_sub_table
                    WHERE car_sub_table.Type_id = {p1}
            """.format(p1=key)
    cursor.execute(command)
    single_category = cursor.fetchall()   
    name = single_category[0][1] 
    
    command = """ DELETE FROM car_sub_table
                    WHERE car_sub_table.Type_id = {p1}
            """.format(p1=key)
    cursor.execute(command)
    conn.commit()    
    
    flash('The category %s has been deleted' % (name), 'success')
    return redirect(url_for('my_view.categories'))