from wtforms import Form, TextField, DecimalField, SelectField
from wtforms.validators import InputRequired, NumberRange
from decimal import Decimal

import sqlite3
sqlite_file = 'car_dealership-3.sqlite'

conn = sqlite3.connect(sqlite_file)
cursor = conn.cursor() 

#category form used as input validtor for category related pages

class CategoryForm(Form):
    Car_type = TextField(
            label='Car_type',
            validators=[InputRequired()]) 
    
    Car_description = TextField(
            label='Car_description',
            validators=[InputRequired()])
            
    Types_in_stock = DecimalField(
            label='Stock', 
            validators=[InputRequired(), NumberRange(min=Decimal('0.0'))])
            
    Make_up_percentage = DecimalField(
            label='Make Up Percent', 
            validators=[InputRequired(), NumberRange(min=Decimal('0.0'))])
            
#productform used as input validator for product related pages
class ProductForm(Form): 

    Name = TextField(
        	label='Product Name',
        	validators=[InputRequired()])  
    
    Price = DecimalField(
            label='Price', 
            validators=[InputRequired(), NumberRange(min=Decimal('0.0'))])
    
    Units_in_stock = DecimalField(
            label='Units', 
            validators=[InputRequired(), NumberRange(min=Decimal('0.0'))])
    
    Product_color = TextField(
            label='Color',
            validators=[InputRequired()]) 
    
    Condition = TextField(
        	label='Condition',
        	validators=[InputRequired()]) 
    
    Type_id = SelectField(
            label='Category', 
            validators=[InputRequired()], coerce=int)
    
    Url = TextField(
        	label='Image URL',
        	validators=[InputRequired()]) 
    
    
class AccountForm(Form):

    username= TextField(
            label='username',
            validators=[InputRequired()])
    password= TextField(
            label='password',
            validators=[InputRequired()])